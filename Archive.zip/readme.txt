_tk - WordPress Theme
Developed by Themekraft - http://themekraft.com

Theme Homepage - http://themekraft.com/store/_tk-free-wordpress-starter-theme-based-on-twitter-bootstrap/

Licensed under GNU General Public License, Version 2.0
http://www.gnu.org/licenses/gpl-2.0.html

The _tk Project on Github - https://github.com/Themekraft/_tk/

We use some great resources in this theme.

Credits:

1. Bootstrap

/*!
 * Bootstrap v3.3.1 (http://getbootstrap.com)
 * Copyright 2011-2014 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */

/*!
 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=f58353a31151a8c05d7c)
 * Config saved to config.json and https://gist.github.com/f58353a31151a8c05d7c
 */

2. wp_bootstrap_navwalker

 * Class Name: wp_bootstrap_navwalker
 * GitHub URI: https://github.com/twittem/wp-bootstrap-navwalker

3. Glyphicons

 * http://getbootstrap.com/components/


*************************************************************


/**
 *
 * PLEASE NEVER CHANGE THE THEME FILES
 *
 * your changes will not be update safe, which would be really sad. :(
 *
 * ----------------------------------------------
 *
 * But we made an extra space for your style changes. :)
 *
 * Simply go to
 *
 * APPEARANCE -> THEME SETTINGS -> CSS
 *
 * andd add your CSS changes there.
 *
 * ----------------------------------------------
 *
 * If you want to change more than CSS, we strongly recommend creating a child theme.
 *
 *
 * Free Tech Support and Premium Support:
 * http://themekraft.com/support
 *
 *
 */


*************************************************************


Thanks for using _tk Theme.
We hope you enjoy it!



***
