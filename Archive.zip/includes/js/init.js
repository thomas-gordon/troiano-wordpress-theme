jQuery(function ($) {


	$('.js-slider').cycle();

});